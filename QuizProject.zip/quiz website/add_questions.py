import sqlite3

def add_questions():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # List of new questions to add
    questions = [
        ('What is the capital of Germany?', 'Berlin', 'Paris', 'Rome', 'Madrid', 'a', 'student'),
        ('What is 12 x 12?', '124', '144', '132', '152', 'b', 'student'),
        ('Who painted the Mona Lisa?', 'Van Gogh', 'Da Vinci', 'Picasso', 'Michelangelo', 'b', 'college'),
        ('What is the boiling point of water?', '100°C', '50°C', '212°F', '32°F', 'a', 'college'),
    ]

    for question in questions:
        # Check if the question already exists in the database
        cursor.execute("SELECT COUNT(*) FROM questions WHERE question = ?", (question[0],))
        if cursor.fetchone()[0] == 0:  # Question does not exist
            cursor.execute('''
            INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, type)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', question)
            print(f"Question added: {question[0]}")
        else:
            print(f"Duplicate question skipped: {question[0]}")

    conn.commit()
    conn.close()
    print("Questions added successfully!")

# Run this script to insert questions
add_questions()
