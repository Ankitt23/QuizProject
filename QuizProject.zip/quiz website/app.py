from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # For session management (e.g., login)

# Database connection
def connect_db():
    return sqlite3.connect('database.db')

@app.route('/')
def home():
    """Render the homepage with dynamic Login/Logout button and username display."""
    user_logged_in = 'user' in session  # Check if the user is logged in
    return render_template('home.html', user_logged_in=user_logged_in)

@app.route('/about')
def about():
    """Render the About page."""
    user_logged_in = 'user' in session  # Check if the user is logged in
    return render_template('about.html', user_logged_in=user_logged_in)

@app.route('/leaderboard')
def leaderboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect if not logged in

    conn = connect_db()
    cursor = conn.cursor()
    
    # Fetch the leaderboard sorted by highest score
    cursor.execute("""
        SELECT users.username, SUM(quiz_results.score) as total_score
        FROM quiz_results
        JOIN users ON quiz_results.user_id = users.id
        GROUP BY users.id
        ORDER BY total_score DESC
    """)
    leaderboard_data = cursor.fetchall()
    conn.close()

    # ✅ Pass `enumerate` to `render_template`
    return render_template('leaderboard.html', leaderboard=leaderboard_data, enumerate=enumerate)



@app.route('/quiz-history')
def quiz_history():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect only if not logged in

    user_id = session['user_id']
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT quiz_type, score, date_taken
        FROM quiz_results
        WHERE user_id = ?
        ORDER BY date_taken DESC
    ''', (user_id,))
    history = cursor.fetchall()
    conn.close()

    return render_template('quiz_history.html', username=session['user'], history=history)

#admin view user route
@app.route('/admin/users')
def view_all_users():
    """View all registered users."""
    # Ensure only admins can access
    if 'user' not in session or session['user'] != 'admin':
        return redirect(url_for('login'))

    conn = connect_db()
    cursor = conn.cursor()

    # Fetch all users with their passwords from the database
    cursor.execute("SELECT id, username, password FROM users")
    users = cursor.fetchall()
    conn.close()

    return render_template('view_users.html', users=users)

#admin delete route
@app.route('/admin/delete', methods=['POST'])
def delete_question():
    """Delete a question from the database."""
    if 'user' not in session or session['user'] != 'admin':  # Ensure only admin can access
        return redirect(url_for('login'))

    question_id = request.form.get('question_id')

    if question_id:
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM questions WHERE id = ?", (question_id,))
        conn.commit()
        conn.close()

    return redirect(url_for('admin'))

#admin edit route
@app.route('/admin/edit', methods=['GET', 'POST'])
def edit_question():
    """Edit a question in the database."""
    if 'user' not in session or session['user'] != 'admin':  # Ensure only admin can access
        return redirect(url_for('login'))

    if request.method == 'POST':
        # Update the question in the database
        question_id = request.form.get('question_id')
        question = request.form.get('question')
        option_a = request.form.get('option_a')
        option_b = request.form.get('option_b')
        option_c = request.form.get('option_c')
        option_d = request.form.get('option_d')
        correct_option = request.form.get('correct_option')
        quiz_type = request.form.get('quiz_type')

        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute('''
        UPDATE questions
        SET question = ?, option_a = ?, option_b = ?, option_c = ?, option_d = ?, correct_option = ?, type = ?
        WHERE id = ?
        ''', (question, option_a, option_b, option_c, option_d, correct_option, quiz_type, question_id))
        conn.commit()
        conn.close()

        return redirect(url_for('admin'))

    # Render the edit form with existing question data
    question_id = request.args.get('question_id')
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM questions WHERE id = ?", (question_id,))
    question = cursor.fetchone()
    conn.close()

    return render_template('edit_question.html', question=question)


#admin route
@app.route('/admin', methods=['GET', 'POST'])
def admin():
    """Admin page for managing quiz questions."""
    if 'user' not in session or session['user'] != 'admin':  # Ensure only 'admin' can access
        return redirect(url_for('login'))

    conn = connect_db()
    cursor = conn.cursor()

    if request.method == 'POST':
        # Safely retrieve form data
        quiz_type = request.form.get('quiz_type')  # 'student' or 'college'
        question = request.form.get('question')
        option_a = request.form.get('option_a')
        option_b = request.form.get('option_b')
        option_c = request.form.get('option_c')
        option_d = request.form.get('option_d')
        correct_option = request.form.get('correct_option')

        # Validate input
        if not all([quiz_type, question, option_a, option_b, option_c, option_d, correct_option]):
            return "All fields are required!", 400

        # Insert the question into the database
        cursor.execute('''
        INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, type)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (question, option_a, option_b, option_c, option_d, correct_option, quiz_type))
        conn.commit()

    # Fetch all questions to display on the admin page
    cursor.execute("SELECT id, question, type FROM questions")
    questions = cursor.fetchall()
    conn.close()

    return render_template('admin.html', questions=questions)


#quiz route

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    """Render quiz questions one by one and handle quiz submissions."""
    if 'user' not in session:
        return redirect(url_for('login'))

    quiz_type = request.args.get('type', 'movie')  # Default quiz type
    question_index = int(request.args.get('q', 0))  # Track question index

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id, question, option_a, option_b, option_c, option_d, correct_option FROM questions WHERE type = ?", (quiz_type,))
    questions = cursor.fetchall()
    conn.close()

    if not questions:
        return "No questions found for this quiz type."

    # If user submitted an answer
    if request.method == 'POST':
        user_answers = session.get('quiz_answers', {})
        question_id = request.form['question_id']
        user_answers[question_id] = request.form['answer']
        session['quiz_answers'] = user_answers

        # If this was the last question, redirect to results page
        if question_index + 1 >= len(questions):
            session['quiz_type'] = quiz_type  # Ensure quiz_type is saved in sessio
            return redirect(url_for('quiz_results'))  # Go to result page

        # Otherwise, move to the next question
        return redirect(url_for('quiz', type=quiz_type, q=question_index + 1))

    # Ensure question_index is within range before accessing questions list
    if question_index >= len(questions):
        return redirect(url_for('quiz_results'))  # Redirect to results if out of bounds

    # Get the current question
    question = questions[question_index]

    return render_template('quiz.html',
                           question=question,
                           question_index=question_index + 1,  # Show 1-based index
                           total_questions=len(questions),
                           quiz_type=quiz_type)


@app.route('/quiz-results', methods=['GET', 'POST'])
def quiz_results():
    """Calculate and display quiz results properly."""
    if 'quiz_answers' not in session or 'quiz_type' not in session:
        return redirect(url_for('home'))  # Redirect if no quiz has been taken

    conn = connect_db()
    cursor = conn.cursor()

    score = 0
    total_questions = len(session['quiz_answers'])
    quiz_type = session.get('quiz_type', 'Unknown')  # Get the correct quiz type
    results = []

    for question_id, user_answer in session['quiz_answers'].items():
        cursor.execute("""
            SELECT question, option_a, option_b, option_c, option_d, correct_option 
            FROM questions WHERE id = ?""", (question_id,))
        question_data = cursor.fetchone()

        if question_data:
            question_text, option_a, option_b, option_c, option_d, correct_option = question_data

            # Convert correct_option (stored as 'a', 'b', 'c', or 'd') to the actual text
            options = {'a': option_a, 'b': option_b, 'c': option_c, 'd': option_d}
            correct_text = options.get(correct_option, "Unknown")
            user_text = options.get(user_answer, "No Answer")  # Handle cases where user didn't answer

            # Check if the answer is correct
            is_correct = (user_answer == correct_option)
            if is_correct:
                score += 1  # Increase score if correct

            results.append({
                'question': question_text,
                'user_answer_key': user_answer,  # Store the selected answer key ('a', 'b', etc.)
                'user_answer': user_text,  # Store the actual answer text
                'correct_answer_key': correct_option,  # Store correct answer key
                'correct_answer': correct_text,  # Store correct answer text
                'options': options,  # Store answer choices
                'is_correct': is_correct
            })

    # Save the quiz result to the database with the correct quiz type
    if 'user_id' in session:
        user_id = session['user_id']
        cursor.execute("""
            INSERT INTO quiz_results (user_id, quiz_type, score) 
            VALUES (?, ?, ?)""", (user_id, quiz_type, score))
        conn.commit()

    conn.close()

    # Clear the session quiz answers after the quiz is done
    session.pop('quiz_answers', None)
    session.pop('quiz_type', None)  # Remove quiz type after completion

    return render_template(
        'result.html', 
        score=score, 
        results=results, 
        total=total_questions, 
        quiz_type=quiz_type
    )

#user login
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Render login page and handle login functionality."""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Validate user credentials
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT id, username FROM users WHERE username = ? AND password = ?", (username, password))
        user = cursor.fetchone()
        conn.close()

        if user:
            session['user_id'] = user[0]  # Store user ID in session
            session['user'] = user[1]    # Store username in session
            next_page = request.args.get('next')
            return redirect(next_page or url_for('home'))
        else:
            return render_template('login.html', error="Invalid username or password")

    return render_template('login.html')

#user register
@app.route('/register', methods=['GET', 'POST'])
def register():
    """Render registration page and handle new user registration."""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Insert new user into the database
        conn = connect_db()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            conn.commit()
            conn.close()
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('register.html', error="Username already exists!")

    return render_template('register.html')

#user logout
@app.route('/logout')
def logout():
    """Logout the user by clearing the session."""
    session.pop('user', None)
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.run(debug=True)
