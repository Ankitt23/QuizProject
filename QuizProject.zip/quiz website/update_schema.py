import sqlite3

def update_schema():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Add the 'type' column if it doesn't already exist
    try:
        cursor.execute("ALTER TABLE questions ADD COLUMN type TEXT")
        print("Column 'type' added successfully!")
    except sqlite3.OperationalError:
        print("Column 'type' already exists!")

    conn.commit()
    conn.close()

# Run this script to update the schema
update_schema()
