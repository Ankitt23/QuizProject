import sqlite3

def initialize_database():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # ✅ **Fix: Add 'type' column to `questions` to match app.py**
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question TEXT NOT NULL,
        option_a TEXT NOT NULL,
        option_b TEXT NOT NULL,
        option_c TEXT NOT NULL,
        option_d TEXT NOT NULL,
        correct_option TEXT NOT NULL,
        type TEXT NOT NULL  -- ✅ ADDED THIS to match `app.py`
    )
    ''')

    # ✅ **Users Table (Correct)**
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
    ''')

    # ✅ **Quiz Results Table (Fixed)**
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS quiz_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        quiz_type TEXT NOT NULL,
        score INTEGER NOT NULL,
        date_taken TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )
    ''')

    # ✅ **Insert Sample Questions with `type`**
    cursor.execute('''
    INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, type)
    VALUES
    ('What is the capital of France?', 'Paris', 'London', 'Berlin', 'Rome', 'a', 'geography'),
    ('What is 5 + 7?', '10', '11', '12', '13', 'c', 'math'),
    ('Which programming language is this website built with?', 'Python', 'Java', 'C++', 'Ruby', 'a', 'tech')
    ''')

    conn.commit()
    conn.close()
    print("Database initialized successfully!")

# Run this script only once to initialize the database
initialize_database()
